# order/workers.py
import logging
import os
import time
from typing import Dict, Any

from conductor.client.configuration.configuration import Configuration
from conductor.client.orkes_clients import OrkesClients
from conductor.client.http.models import StartWorkflowRequest, TaskResult as CTaskResult

from sqlalchemy.orm import Session
from utils.config import get_db
from utils.model import Order, OrderStatus
from order.service import OrderService

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# ---- Client Conductor (URL e credenziali via ENV, es: CONDUCTOR_SERVER_URL)
_cfg = Configuration()
_clients = OrkesClients(configuration=_cfg)
_workflows = _clients.get_workflow_client()
_tasks = _clients.get_task_client()

# ---- Start workflow (equivalente al tuo startOrderFlow Java)
def start_order_flow(order_dto) -> Dict[str, Any]:
    req = StartWorkflowRequest()
    req.name = "order-saga"
    req.input = {
        "orderId": order_dto.order_id,
        "productIds": order_dto.product_ids,
        "customerId": order_dto.customer_id,
        "creditCardNumber": order_dto.credit_card_number,
        "status": order_dto.status,
    }
    workflow_id = _workflows.start_workflow(req)
    return {"workflowId": workflow_id}

# ---- Handlers dei task ----

def handle_persist_pending_order(task_input: dict) -> dict:
    # Crea un Order e persistilo se non esiste
    db: Session = next(get_db())
    try:
        svc = OrderService(db)
        entity = Order(
            product_ids=task_input.get("productIds"),
            customer_id=task_input.get("customerId"),
            credit_card_number=task_input.get("creditCardNumber"),
        )
        if task_input.get("orderId"):
            entity.order_id = task_input["orderId"]
        svc.place_pending_order(entity)
        return {"result": "PASS"}
    finally:
        db.close()

def handle_delete_pending_order(task_input: dict) -> dict:
    db: Session = next(get_db())
    try:
        svc = OrderService(db)
        svc.delete_pending_order(task_input.get("orderId"))
        return {"result": "PASS"}
    finally:
        db.close()

def handle_confirm_pending_order(task_input: dict) -> dict:
    db: Session = next(get_db())
    try:
        svc = OrderService(db)
        svc.confirm_pending_order(task_input.get("orderId"))
        return {"result": "PASS"}
    finally:
        db.close()

# Mapping taskType -> handler
HANDLERS = {
    "persist-pending-order": handle_persist_pending_order,
    "delete-pending-order":  handle_delete_pending_order,
    "confirm-pending-order": handle_confirm_pending_order,
}

# ---- Runner di polling (semplice e solido)
def run(poll_interval_sec: int = 2, batch_size: int = 5, domain: str | None = None):
    logger.info("Starting workers... domain=%s", domain)
    known_types = list(HANDLERS.keys())
    while True:
        try:
            for task_type in known_types:
                polled = _tasks.batch_poll(
                    task_type=task_type, 
                    worker_id="order-service", 
                    count=batch_size, 
                    domain=domain
                )
                for t in polled or []:
                    try:
                        handler = HANDLERS[task_type]
                        output = handler(t.inputData or {})
                        tr = CTaskResult(
                            taskId=t.taskId, 
                            workflowInstanceId=t.workflowInstanceId, 
                            status="COMPLETED"
                        )
                        tr.outputData = output
                        _tasks.update_task(tr)
                    except Exception as ex:
                        logger.exception("Task %s failed: %s", t.taskId, ex)
                        tr = CTaskResult(
                            taskId=t.taskId, 
                            workflowInstanceId=t.workflowInstanceId, 
                            status="FAILED"
                        )
                        tr.reasonForIncompletion = str(ex)
                        _tasks.update_task(tr)
        except Exception as loop_ex:
            logger.exception("Polling loop error: %s", loop_ex)

        time.sleep(poll_interval_sec)
