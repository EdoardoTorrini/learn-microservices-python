from order.workers import run
import os

if __name__ == "__main__":
    run(poll_interval_sec=2, batch_size=5, domain=os.getenv("ORDER_WORKER_DOMAIN"))