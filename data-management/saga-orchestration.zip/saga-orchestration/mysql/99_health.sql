CREATE TABLE IF NOT EXISTS init_complete (flag BOOLEAN);
INSERT INTO init_complete (flag) VALUES (TRUE);